@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.example.clipforge

import android.app.Activity
import android.content.Context
import android.database.Cursor
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Background = Color(0xFF0C0D14)
private val Panel = Color(0xFF171925)
private val PanelLight = Color(0xFF202335)
private val Accent = Color(0xFF9575FF)
private val MainText = Color(0xFFF7F5FF)
private val MutedText = Color(0xFFAAAEC4)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Accent,
                    onPrimary = Color.White,
                    background = Background,
                    surface = Panel,
                    onSurface = MainText,
                    onSurfaceVariant = MutedText,
                    outline = Color(0xFF3A3E57)
                )
            ) {
                Surface(modifier = Modifier.fillMaxSize(), color = Background) {
                    ClipForgeScreen(this@MainActivity)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ClipForgeScreen(context: Context) {
    val scope = rememberCoroutineScope()
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var sourceName by remember { mutableStateOf("") }
    var durationMs by remember { mutableIntStateOf(0) }
    var clipLengthSeconds by remember { mutableIntStateOf(90) }
    var candidates by remember { mutableStateOf<List<ClipAnalyzer.ClipCandidate>>(emptyList()) }
    var analyzing by remember { mutableStateOf(false) }
    var exportingId by remember { mutableStateOf<String?>(null) }
    var statusText by remember { mutableStateOf("Choose a long video to get started.") }

    val busy = analyzing || exportingId != null
    DisposableEffect(busy) {
        val window = (context as? Activity)?.window
        if (busy) window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose { window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
    }

    fun loadVideo(uri: Uri) {
        selectedUri = uri
        candidates = emptyList()
        sourceName = "Reading video…"
        durationMs = 0
        statusText = "Reading video details…"
        scope.launch {
            try {
                val metadata = withContext(Dispatchers.IO) { readVideoDetails(context, uri) }
                sourceName = metadata.first
                durationMs = metadata.second.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
                statusText = if (durationMs >= 60_000) {
                    "Ready to analyze • ${ClipAnalyzer.formatTime(durationMs.toLong())}"
                } else {
                    "This video is under 60 seconds. Choose a longer video."
                }
            } catch (e: Exception) {
                sourceName = "Selected video"
                statusText = e.message ?: "Could not read this video. Try another file."
            }
        }
    }

    val galleryPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri -> if (uri != null) loadVideo(uri) }
    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri -> if (uri != null) loadVideo(uri) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(15.dp))
                    .background(Accent),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color.White, modifier = Modifier.size(27.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("ClipForge", color = MainText, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
                Text("Long video → ready-to-post Shorts", color = MutedText, fontSize = 13.sp)
            }
            Surface(color = PanelLight, shape = RoundedCornerShape(50)) {
                Text("BETA", color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text("Your best moments, picked automatically.", color = MainText, fontSize = 22.sp, fontWeight = FontWeight.Bold, lineHeight = 28.sp)
            Text(
                "Import a long video. ClipForge scans visual activity, ranks possible moments, creates vertical 9:16 clips, and makes a cover for each exported Short.",
                color = MutedText,
                fontSize = 14.sp,
                lineHeight = 21.sp
            )
        }

        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.VideoLibrary, null, tint = Accent)
                    Spacer(Modifier.width(9.dp))
                    Text("1. Select your long video", color = MainText, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = { galleryPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(13.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Accent)
                    ) {
                        Icon(Icons.Default.Movie, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Gallery")
                    }
                    OutlinedButton(
                        onClick = { filePicker.launch(arrayOf("video/*")) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(13.dp)
                    ) {
                        Icon(Icons.Default.FolderOpen, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Files")
                    }
                }
                if (selectedUri != null) {
                    Surface(color = PanelLight, shape = RoundedCornerShape(13.dp), modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, null, tint = Color(0xFF75D6A5), modifier = Modifier.size(21.dp))
                            Spacer(Modifier.width(9.dp))
                            Column(Modifier.weight(1f)) {
                                Text(sourceName, color = MainText, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    if (durationMs > 0) "Duration: ${ClipAnalyzer.formatTime(durationMs.toLong())}" else "Checking duration…",
                                    color = MutedText,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Science, null, tint = Accent)
                    Spacer(Modifier.width(9.dp))
                    Text("2. Find the strongest moments", color = MainText, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                }
                Text("Clip length", color = MutedText, fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(60, 90, 120).forEach { seconds ->
                        FilterChip(
                            selected = clipLengthSeconds == seconds,
                            onClick = { clipLengthSeconds = seconds },
                            label = { Text("${seconds}s") },
                            colors = FilterChipDefaults.filterChipColors(
                                labelColor = MainText,
                                selectedContainerColor = Accent,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
                Button(
                    onClick = {
                        val uri = selectedUri ?: return@Button
                        if (durationMs < 60_000) {
                            statusText = "Choose a video at least 60 seconds long."
                        } else {
                            analyzing = true
                            candidates = emptyList()
                            statusText = "Scanning frames and ranking candidate moments…"
                            scope.launch {
                                try {
                                    val results = withContext(Dispatchers.IO) {
                                        ClipAnalyzer(context).analyze(uri, clipLengthSeconds, 5)
                                    }
                                    candidates = results
                                    statusText = if (results.isNotEmpty()) {
                                        "Found ${results.size} candidate Short${if (results.size == 1) "" else "s"}. Preview covers below."
                                    } else "No suitable clips found. Try a different length or video."
                                } catch (e: Exception) {
                                    statusText = e.message ?: "Video analysis failed. Try another file."
                                } finally {
                                    analyzing = false
                                }
                            }
                        }
                    },
                    enabled = selectedUri != null && !analyzing && exportingId == null,
                    modifier = Modifier.fillMaxWidth().height(51.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent)
                ) {
                    if (analyzing) {
                        CircularProgressIndicator(modifier = Modifier.size(19.dp), strokeWidth = 2.dp, color = Color.White)
                        Spacer(Modifier.width(9.dp))
                        Text("Analyzing video…")
                    } else {
                        Icon(Icons.Default.AutoAwesome, null, modifier = Modifier.size(19.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Analyze & Find Best Clips", fontWeight = FontWeight.Bold)
                    }
                }
                Text(
                    "Scoring runs on your phone. This first version uses visual-detail and scene-change signals; it does not yet understand spoken meaning or story context.",
                    color = MutedText,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
            }
        }

        if (statusText.isNotBlank()) {
            Surface(color = PanelLight, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                Text(statusText, color = MutedText, fontSize = 13.sp, lineHeight = 19.sp, modifier = Modifier.padding(13.dp))
            }
        }

        if (candidates.isNotEmpty()) {
            Column(verticalArrangement = Arrangement.spacedBy(11.dp)) {
                Text("3. Review your Shorts", color = MainText, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Each cover is generated from a frame inside its clip. Export saves both files to your phone.", color = MutedText, fontSize = 13.sp, lineHeight = 19.sp)
                candidates.forEachIndexed { index, candidate ->
                    CandidateCard(
                        rank = index + 1,
                        candidate = candidate,
                        exporting = exportingId == candidate.id,
                        exportEnabled = exportingId == null && !analyzing,
                        onExport = {
                            val uri = selectedUri
                            if (uri == null) {
                                statusText = "Choose a video first."
                            } else {
                                exportingId = candidate.id
                                statusText = "Exporting Short ${index + 1} in vertical 9:16…"
                                ClipExporter(context).export(
                                    sourceUri = uri,
                                    candidate = candidate,
                                    sourceName = sourceName,
                                    onSuccess = { _, _ ->
                                        exportingId = null
                                        statusText = "Short ${index + 1} and its cover saved. Check Movies/AutoClips and Pictures/AutoClips."
                                    },
                                    onFailure = { error ->
                                        exportingId = null
                                        statusText = error
                                    }
                                )
                            }
                        }
                    )
                }
            }
        }

        Spacer(Modifier.height(10.dp))
        Text("CLIPFORGE  •  Local-first video processing", color = Color(0xFF74788F), fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
    }
}

@Composable
private fun CandidateCard(
    rank: Int,
    candidate: ClipAnalyzer.ClipCandidate,
    exporting: Boolean,
    exportEnabled: Boolean,
    onExport: () -> Unit
) {
    val bitmap = remember(candidate.coverPath) {
        val options = BitmapFactory.Options().apply { inSampleSize = 4 }
        BitmapFactory.decodeFile(candidate.coverPath, options)
    }
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(21.dp)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            if (bitmap != null) {
                Image(
                    bitmap = bitmap.asImageBitmap(),
                    contentDescription = "Generated cover for Short $rank",
                    modifier = Modifier.width(102.dp).aspectRatio(9f / 16f).clip(RoundedCornerShape(12.dp)),
                    contentScale = ContentScale.Crop
                )
            } else {
                Box(Modifier.width(102.dp).aspectRatio(9f / 16f).clip(RoundedCornerShape(12.dp)).background(PanelLight))
            }
            Spacer(Modifier.width(13.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("SHORT #$rank", color = Accent, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                Text(
                    "${ClipAnalyzer.formatTime(candidate.startMs)} – ${ClipAnalyzer.formatTime(candidate.endMs)}",
                    color = MainText,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Text("${(candidate.endMs - candidate.startMs) / 1_000}s • Visual score ${candidate.score}/100", color = MutedText, fontSize = 12.sp)
                Spacer(Modifier.height(4.dp))
                Button(
                    onClick = onExport,
                    enabled = exportEnabled,
                    shape = RoundedCornerShape(11.dp),
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent)
                ) {
                    if (exporting) {
                        CircularProgressIndicator(modifier = Modifier.size(17.dp), color = Color.White, strokeWidth = 2.dp)
                        Spacer(Modifier.width(7.dp))
                        Text("Exporting…", fontSize = 12.sp)
                    } else {
                        Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Export Short", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

private fun readVideoDetails(context: Context, uri: Uri): Pair<String, Long> {
    var name = uri.lastPathSegment?.substringAfterLast('/') ?: "Selected video"
    var cursor: Cursor? = null
    try {
        cursor = context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
        if (cursor != null && cursor.moveToFirst()) {
            val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (index >= 0) name = cursor.getString(index) ?: name
        }
    } finally {
        cursor?.close()
    }
    val retriever = MediaMetadataRetriever()
    val duration = try {
        retriever.setDataSource(context, uri)
        retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
    } finally {
        retriever.release()
    }
    return name to duration
}
