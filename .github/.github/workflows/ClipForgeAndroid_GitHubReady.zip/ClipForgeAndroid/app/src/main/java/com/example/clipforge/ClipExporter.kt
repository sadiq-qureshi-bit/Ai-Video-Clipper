@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.example.clipforge

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.effect.Presentation
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Composition
import androidx.media3.transformer.Transformer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream

class ClipExporter(private val context: Context) {
    fun export(
        sourceUri: Uri,
        candidate: ClipAnalyzer.ClipCandidate,
        sourceName: String,
        onSuccess: (videoUri: Uri, coverUri: Uri) -> Unit,
        onFailure: (String) -> Unit
    ) {
        val outputFile = File(context.cacheDir, "clipforge_export_${System.currentTimeMillis()}.mp4")
        val clippedItem = MediaItem.Builder()
            .setUri(sourceUri)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(candidate.startMs)
                    .setEndPositionMs(candidate.endMs)
                    .build()
            )
            .build()

        val editedItem = EditedMediaItem.Builder(clippedItem)
            .setEffects(
                Effects(
                    emptyList(),
                    listOf(
                        Presentation.createForWidthAndHeight(
                            1080,
                            1920,
                            Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP
                        )
                    )
                )
            )
            .build()

        val listener = object : Transformer.Listener {
            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        val safeBase = sourceName.substringBeforeLast('.', sourceName)
                            .replace(Regex("[^A-Za-z0-9_-]"), "_")
                            .take(36)
                            .ifBlank { "Video" }
                        val clipName = "${safeBase}_Short_${System.currentTimeMillis()}"
                        val savedVideo = saveToMediaStore(
                            file = outputFile,
                            collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                            displayName = "$clipName.mp4",
                            mimeType = "video/mp4",
                            relativePath = "${Environment.DIRECTORY_MOVIES}/AutoClips"
                        )
                        val coverFile = File(candidate.coverPath)
                        val savedCover = saveToMediaStore(
                            file = coverFile,
                            collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                            displayName = "${clipName}_Cover.jpg",
                            mimeType = "image/jpeg",
                            relativePath = "${Environment.DIRECTORY_PICTURES}/AutoClips"
                        )
                        outputFile.delete()
                        withContext(Dispatchers.Main) { onSuccess(savedVideo, savedCover) }
                    } catch (e: Exception) {
                        outputFile.delete()
                        withContext(Dispatchers.Main) { onFailure(e.message ?: "Couldn't save the exported clip.") }
                    }
                }
            }

            override fun onError(
                composition: Composition,
                exportResult: ExportResult,
                exportException: ExportException
            ) {
                outputFile.delete()
                onFailure("Export failed: ${exportException.message ?: "unsupported video format"}")
            }
        }

        try {
            Transformer.Builder(context)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(listener)
                .build()
                .start(editedItem, outputFile.absolutePath)
        } catch (e: Exception) {
            outputFile.delete()
            onFailure(e.message ?: "Couldn't start the export.")
        }
    }

    private fun saveToMediaStore(
        file: File,
        collection: Uri,
        displayName: String,
        mimeType: String,
        relativePath: String
    ): Uri {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
            put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
            put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val resolver = context.contentResolver
        val uri = resolver.insert(collection, values)
            ?: throw IllegalStateException("Android couldn't create the output file.")
        try {
            resolver.openOutputStream(uri, "w")?.use { output ->
                FileInputStream(file).use { input -> input.copyTo(output) }
            } ?: throw IllegalStateException("Android couldn't open the output file.")
            val ready = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
            resolver.update(uri, ready, null, null)
            return uri
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
    }
}
