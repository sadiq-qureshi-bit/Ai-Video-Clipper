package com.example.clipforge

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Local-first candidate ranking. This is a visual-activity heuristic, not a semantic AI model:
 * it scores scene changes, visible detail/contrast, and usable brightness without uploading video.
 */
class ClipAnalyzer(private val context: Context) {
    data class FrameSample(
        val timeMs: Long,
        val quality: Double,
        val motion: Double,
        val gray: IntArray
    )

    data class ClipCandidate(
        val id: String,
        val startMs: Long,
        val endMs: Long,
        val score: Int,
        val coverPath: String
    )

    fun analyze(uri: Uri, desiredSeconds: Int, count: Int = 5): List<ClipCandidate> {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: throw IllegalArgumentException("Can't read the video duration.")
            if (durationMs < 60_000L) {
                throw IllegalArgumentException("Please choose a video that is at least 60 seconds long.")
            }

            val clipLengthMs = min(durationMs, desiredSeconds * 1_000L)
            val durationSeconds = durationMs / 1_000.0
            val intervalMs = max(3_000L, (durationSeconds / 900.0 * 1_000.0).toLong())
            val sampleCount = min(1_200, (durationMs / intervalMs).toInt() + 1)
            val raw = ArrayList<Pair<Long, Pair<Double, IntArray>>>(sampleCount)

            var t = 0L
            var index = 0
            while (t < durationMs && index < 1_200) {
                val frame = getSmallFrame(retriever, t)
                if (frame != null) {
                    val metrics = measureFrame(frame)
                    raw.add(t to (metrics.first to metrics.second))
                    frame.recycle()
                    index++
                }
                t += intervalMs
            }

            if (raw.size < 2) throw IllegalArgumentException("Not enough readable frames in this video.")
            val samples = raw.mapIndexed { i, item ->
                val quality = item.second.first
                val motion = if (i == 0) 0.0 else grayDifference(raw[i - 1].second.second, item.second.second)
                FrameSample(item.first, quality, min(1.0, motion * 3.6), item.second.second)
            }

            val lastStart = max(0L, durationMs - clipLengthMs)
            val strideMs = max(12_000L, clipLengthMs / 5)
            val starts = ArrayList<Long>()
            var start = 0L
            while (start <= lastStart) {
                starts.add(start)
                start += strideMs
            }
            if (starts.isEmpty() || starts.last() != lastStart) starts.add(lastStart)

            val scored = starts.distinct().map { s ->
                val e = min(durationMs, s + clipLengthMs)
                val inWindow = samples.filter { it.timeMs >= s && it.timeMs <= e }
                val quality = if (inWindow.isEmpty()) 0.0 else inWindow.map { it.quality }.average()
                val motion = if (inWindow.isEmpty()) 0.0 else inWindow.map { it.motion }.average()
                // Favor visible detail and movement, while avoiding a score based on cuts alone.
                val score = (quality * 0.62 + motion * 0.38).coerceIn(0.0, 1.0)
                Triple(s, e, score)
            }.sortedByDescending { it.third }

            val chosen = ArrayList<Triple<Long, Long, Double>>()
            for (candidate in scored) {
                if (chosen.none { existing -> overlap(candidate.first, candidate.second, existing.first, existing.second) > clipLengthMs * 0.38 }) {
                    chosen.add(candidate)
                    if (chosen.size >= count) break
                }
            }
            // If a very short source produces only highly overlapping choices, show the top-ranked one.
            if (chosen.isEmpty() && scored.isNotEmpty()) chosen.add(scored.first())

            val coverDir = File(context.cacheDir, "clipforge_covers").apply { mkdirs() }
            return chosen.mapIndexed { i, item ->
                val (startMs, endMs, score) = item
                val bestSample = samples
                    .filter { it.timeMs in startMs..endMs }
                    .maxByOrNull { it.quality * 0.65 + it.motion * 0.35 }
                val coverAt = bestSample?.timeMs ?: (startMs + endMs) / 2
                val sourceFrame = getCoverFrame(retriever, coverAt)
                    ?: getCoverFrame(retriever, (startMs + endMs) / 2)
                    ?: throw IllegalArgumentException("Couldn't create a cover frame.")
                val coverFile = File(coverDir, "cover_${System.currentTimeMillis()}_$i.jpg")
                drawCover(sourceFrame, coverFile, startMs, endMs)
                sourceFrame.recycle()
                ClipCandidate(
                    id = "${startMs}_${endMs}",
                    startMs = startMs,
                    endMs = endMs,
                    score = (score * 100).toInt(),
                    coverPath = coverFile.absolutePath
                )
            }
        } finally {
            retriever.release()
        }
    }

    private fun getSmallFrame(retriever: MediaMetadataRetriever, timeMs: Long): Bitmap? {
        return try {
            if (Build.VERSION.SDK_INT >= 27) {
                retriever.getScaledFrameAtTime(
                    timeMs * 1_000L,
                    MediaMetadataRetriever.OPTION_CLOSEST_SYNC,
                    160,
                    90
                )
            } else {
                retriever.getFrameAtTime(timeMs * 1_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    ?.let { original ->
                        val small = Bitmap.createScaledBitmap(original, 160, 90, true)
                        if (small !== original) original.recycle()
                        small
                    }
            }
        } catch (_: RuntimeException) {
            null
        }
    }

    /**
     * Returns a full-quality frame (already rotated correctly by Android) and shrinks it,
     * keeping its original aspect ratio, so very large 4K/8K frames don't exhaust memory.
     * getScaledFrameAtTime() is intentionally not used here because it can stretch the picture.
     */
    private fun getCoverFrame(retriever: MediaMetadataRetriever, timeMs: Long): Bitmap? {
        return try {
            val original = retriever.getFrameAtTime(
                timeMs * 1_000L,
                MediaMetadataRetriever.OPTION_CLOSEST
            ) ?: return null
            val longSide = max(original.width, original.height)
            if (longSide <= 1920) {
                original
            } else {
                val ratio = 1920.0 / longSide
                val scaled = Bitmap.createScaledBitmap(
                    original,
                    max(1, (original.width * ratio).toInt()),
                    max(1, (original.height * ratio).toInt()),
                    true
                )
                if (scaled !== original) original.recycle()
                scaled
            }
        } catch (_: RuntimeException) {
            null
        } catch (_: OutOfMemoryError) {
            null
        }
    }

    private fun measureFrame(bitmap: Bitmap): Pair<Double, IntArray> {
        val small = if (bitmap.width == 32 && bitmap.height == 18) bitmap else Bitmap.createScaledBitmap(bitmap, 32, 18, true)
        val pixels = IntArray(32 * 18)
        small.getPixels(pixels, 0, 32, 0, 0, 32, 18)
        if (small !== bitmap) small.recycle()
        val gray = IntArray(pixels.size)
        var sum = 0.0
        for (i in pixels.indices) {
            val p = pixels[i]
            val value = (Color.red(p) * 0.299 + Color.green(p) * 0.587 + Color.blue(p) * 0.114).toInt()
            gray[i] = value
            sum += value
        }
        val mean = sum / gray.size
        var variance = 0.0
        var edgeTotal = 0.0
        var edgeCount = 0
        for (y in 0 until 18) {
            for (x in 0 until 32) {
                val i = y * 32 + x
                variance += (gray[i] - mean) * (gray[i] - mean)
                if (x < 31) {
                    edgeTotal += abs(gray[i] - gray[i + 1])
                    edgeCount++
                }
                if (y < 17) {
                    edgeTotal += abs(gray[i] - gray[i + 32])
                    edgeCount++
                }
            }
        }
        val contrast = min(1.0, sqrt(variance / gray.size) / 64.0)
        val detail = min(1.0, (edgeTotal / max(1, edgeCount)) / 48.0)
        val brightness = (1.0 - abs(mean - 128.0) / 128.0).coerceIn(0.0, 1.0)
        val quality = (contrast * 0.50 + detail * 0.32 + brightness * 0.18).coerceIn(0.0, 1.0)
        return quality to gray
    }

    private fun grayDifference(a: IntArray, b: IntArray): Double {
        val length = min(a.size, b.size)
        if (length == 0) return 0.0
        var total = 0.0
        for (i in 0 until length) total += abs(a[i] - b[i])
        return total / length / 255.0
    }

    private fun overlap(aStart: Long, aEnd: Long, bStart: Long, bEnd: Long): Long =
        max(0L, min(aEnd, bEnd) - max(aStart, bStart))

    private fun drawCover(source: Bitmap, target: File, startMs: Long, endMs: Long) {
        val width = 1080
        val height = 1920
        val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        canvas.drawColor(Color.BLACK)
        val scale = max(width.toFloat() / source.width, height.toFloat() / source.height)
        val drawWidth = source.width * scale
        val drawHeight = source.height * scale
        val left = (width - drawWidth) / 2f
        val top = (height - drawHeight) / 2f
        val imagePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        canvas.drawBitmap(source, null, RectF(left, top, left + drawWidth, top + drawHeight), imagePaint)

        val shadePaint = Paint(Paint.ANTI_ALIAS_FLAG)
        shadePaint.shader = LinearGradient(
            0f, 0f, 0f, height.toFloat(),
            intArrayOf(Color.argb(80, 0, 0, 0), Color.TRANSPARENT, Color.argb(230, 0, 0, 0)),
            floatArrayOf(0f, 0.42f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), shadePaint)

        val brandPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 42f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }
        canvas.drawText("CLIPFORGE  /  AUTO SHORT", 63f, 108f, brandPaint)

        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 87f
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            setShadowLayer(7f, 0f, 3f, Color.BLACK)
        }
        canvas.drawText("BEST MOMENT", 63f, 1635f, titlePaint)

        val subtitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(225, 220, 255)
            textSize = 45f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        canvas.drawText("${formatTime(startMs)} — ${formatTime(endMs)}", 66f, 1716f, subtitlePaint)
        val footer = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; alpha = 200; textSize = 35f }
        canvas.drawText("VERTICAL SHORT • 9:16", 66f, 1830f, footer)

        FileOutputStream(target).use { outputStream ->
            output.compress(Bitmap.CompressFormat.JPEG, 91, outputStream)
            outputStream.flush()
        }
        output.recycle()
    }

    companion object {
        fun formatTime(timeMs: Long): String {
            val totalSeconds = timeMs / 1_000
            val hours = totalSeconds / 3_600
            val minutes = (totalSeconds % 3_600) / 60
            val seconds = totalSeconds % 60
            return if (hours > 0) String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
            else String.format(Locale.US, "%02d:%02d", minutes, seconds)
        }
    }
}
