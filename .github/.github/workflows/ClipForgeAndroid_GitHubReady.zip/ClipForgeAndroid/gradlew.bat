@echo off
setlocal
set VERSION=8.13
set CACHE_ROOT=%USERPROFILE%\.gradle\clipforge-bootstrap
set GRADLE_HOME=%CACHE_ROOT%\gradle-%VERSION%
set ZIP=%CACHE_ROOT%\gradle-%VERSION%-bin.zip
if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  if not exist "%CACHE_ROOT%" mkdir "%CACHE_ROOT%"
  set ZIP=%CACHE_ROOT%\gradle-%VERSION%-bin.zip
  if not exist "%ZIP%" (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip' -OutFile '%CACHE_ROOT%\gradle-%VERSION%-bin.zip'"
    if errorlevel 1 exit /b 1
  )
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Path '%CACHE_ROOT%\gradle-%VERSION%-bin.zip' -DestinationPath '%CACHE_ROOT%' -Force"
  if errorlevel 1 exit /b 1
)
call "%GRADLE_HOME%\bin\gradle.bat" %*
endlocal
